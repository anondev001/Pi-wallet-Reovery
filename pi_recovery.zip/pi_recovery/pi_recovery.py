import os
import sys
import time
import hmac
import hashlib
import itertools
import json
import csv
import difflib
import re
import threading
from typing import List, Optional, Tuple, Dict
from mnemonic import Mnemonic
from stellar_sdk.keypair import Keypair
from multiprocessing import Pool, cpu_count
from datetime import datetime

# Try to import PIL for image generation
try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    Image = None

# Try to import tqdm for progress bars, fallback to a functional mock
try:
    from tqdm import tqdm
except ImportError:
    class tqdm:
        def __init__(self, iterable=None, total=None, desc="", unit="", **kwargs):
            self.iterable = iterable
            self.total = total
            self.desc = desc
            self.n = 0
            self.unit = unit
        def __iter__(self):
            if self.iterable:
                for item in self.iterable:
                    yield item
                    self.update(1)
            else:
                return self
        def update(self, n=1):
            self.n += n
            if self.total:
                print(f"{self.desc}: {self.n}/{self.total} {self.n/self.total:.1%}", end='\r')
            else:
                print(f"{self.desc}: {self.n} checked...", end='\r')
        def __enter__(self): return self
        def __exit__(self, *args): print()

# Try to import qrcode for QR generation
try:
    import qrcode
except ImportError:
    qrcode = None

# --- COLORS & UI ---
class Colors:
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

# --- CONSTANTS ---
BIP39_LANGUAGE = "english"
PI_DERIVATION_PATH = "m/44'/314159'/0'"
RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "RESULTS_STORAGE")
WATCHLIST_FILE = os.path.join(RESULTS_DIR, "watchlist.json")
SESSION_FILE = os.path.join(RESULTS_DIR, "recovery_session.json")

# --- UTILS ---
def clear_screen(): os.system('cls' if os.name == 'nt' else 'clear')

def ensure_dirs():
    if not os.path.exists(RESULTS_DIR): os.makedirs(RESULTS_DIR)

def clean_input_phrase(text: str) -> str:
    """Resolves multiple spaces between words to a single space."""
    return " ".join(text.strip().lower().split())

def get_int_input(prompt: str, min_val: Optional[int] = None, max_val: Optional[int] = None) -> int:
    """Safely gets integer input with validation and error looping."""
    while True:
        val = input(prompt).strip()
        if val.lower() in ['b', 'back']: return -1
        if val.lower() in ['q', 'quit', 'exit']: sys.exit(0)
        try:
            num = int(val)
            if (min_val is not None and num < min_val) or (max_val is not None and num > max_val):
                print(f"{Colors.RED}[!] Out of range.{Colors.RESET}")
                continue
            return num
        except ValueError:
            print(f"{Colors.RED}[!] Please enter a valid number.{Colors.RESET}")

def load_watchlist() -> List[Dict]:
    if os.path.exists(WATCHLIST_FILE):
        try:
            with open(WATCHLIST_FILE, 'r') as f: return json.load(f)
        except: return []
    return []

def save_watchlist(data: List[Dict]):
    ensure_dirs()
    with open(WATCHLIST_FILE, 'w') as f: json.dump(data, f, indent=4)

def load_session() -> Optional[Dict]:
    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, 'r') as f: return json.load(f)
        except: return None
    return None

def save_session(data: Dict):
    ensure_dirs()
    with open(SESSION_FILE, 'w') as f: json.dump(data, f, indent=4)

def clear_session():
    if os.path.exists(SESSION_FILE): os.remove(SESSION_FILE)

def save_result(data: Dict, filename_prefix: str = "recovery"):
    ensure_dirs()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = os.path.join(RESULTS_DIR, f"{filename_prefix}_{timestamp}.txt")
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(f"=== PI WALLET TOOL RESULT ===\n")
        f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("=" * 60 + "\n")
        for k, v in data.items():
            f.write(f"{k.upper()}: {v}\n")
        f.write("=" * 60 + "\n")
    return filepath

def print_banner():
    banner = f"""{Colors.BOLD}{Colors.CYAN}
    ██████╗ ███████╗███╗   ██╗    ██████╗ ███████╗██╗   ██╗
    ██╔══██╗██╔════╝████╗  ██║    ██╔══██╗██╔════╝██║   ██║
    ██████╔╝█████╗  ██╔██╗ ██║    ██║  ██║█████╗  ██║   ██║
    ██╔══██╗██╔══╝  ██║╚██╗██║    ██║  ██║██╔══╝  ╚██╗ ██╔╝
    ██████╔╝███████╗██║ ╚████║    ██████╔╝███████╗ ╚████╔╝ 
    ╚═════╝ ╚══════╝╚═╝  ╚═══╝    ╚═════╝ ╚══════╝  ╚═══╝  
                                                           
              {Colors.MAGENTA}PI NETWORK MASTER RECOVERY SUITE V1.0{Colors.RESET}
              {Colors.BLUE}Developed by: BEN DEV 🤖❤️{Colors.RESET}
    {Colors.RED}NOTICE: For educational purpose only. Do not use illegally.{Colors.RESET}
    {Colors.YELLOW}=========================================================={Colors.RESET}
    """
    print(banner)

def display_qr(text: str):
    if not qrcode:
        print(f"{Colors.RED}[!] missing qrcode library.{Colors.RESET}")
        return
    qr = qrcode.QRCode(version=1, box_size=1, border=2)
    qr.add_data(text)
    qr.make(fit=True)
    qr.print_ascii(invert=True)

def save_as_png(data: Dict, filename_prefix: str = "wallet"):
    if not qrcode:
        print(f"{Colors.RED}[!] qrcode library not found. Cannot save PNG.{Colors.RESET}")
        return None
    
    ensure_dirs()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = os.path.join(RESULTS_DIR, f"{filename_prefix}_{timestamp}.png")
    
    # Save a clean, raw QR code of the Public Address
    qr = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data(data.get('pub', ''))
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img.save(filepath)
    return filepath

# --- CORE LOGIC ---

# --- CORE LOGIC ---
def derive_path(path: str, seed: bytes) -> bytes:
    master = hmac.new(b"ed25519 seed", seed, hashlib.sha512).digest()
    k, c = master[:32], master[32:]
    for i in path.split('/')[1:]:
        index = int(i[:-1]) + 0x80000000
        data = bytes([0]) + k + index.to_bytes(4, 'big')
        h = hmac.new(c, data, hashlib.sha512).digest()
        k, c = h[:32], h[32:]
    return k

def get_keys(mnemonic: str) -> Optional[Dict]:
    mnemonic = clean_input_phrase(mnemonic)
    try:
        mnemo = Mnemonic(BIP39_LANGUAGE)
        if not mnemo.check(mnemonic): return None
        seed = mnemo.to_seed(mnemonic)
        derived_key = derive_path(PI_DERIVATION_PATH, seed)
        kp = Keypair.from_raw_ed25519_seed(derived_key)
        return {"pub": kp.public_key, "sec": kp.secret, "mnemonic": mnemonic}
    except: return None

# --- TOOLS ---

def tool_generate_keys():
    while True:
        clear_screen(); print_banner()
        print(f"{Colors.YELLOW}--- PI KEY ANALYZER ---{Colors.RESET}")
        m_raw = input(f"{Colors.BLUE}Enter 24-word Passphrase: {Colors.RESET}").strip()
        if not m_raw: return
        
        m = clean_input_phrase(m_raw)
        words = m.split()
        wordlist = Mnemonic(BIP39_LANGUAGE).wordlist
        
        valid = True
        err = ""
        if len(words) != 24:
            err = f"{Colors.RED}[ERROR] Phrase key is not complete (24 words expected). You entered {len(words)} words.{Colors.RESET}"
            valid = False
        
        if valid:
            invalid_words = [w for w in words if w not in wordlist]
            if invalid_words:
                err = f"{Colors.RED}[ERROR] Invalid Words Found: {', '.join(invalid_words)}{Colors.RESET}"
                valid = False

        if valid and not Mnemonic(BIP39_LANGUAGE).check(m):
            err = f"{Colors.RED}[ERROR] Invalid Mnemonic Phrase (Checksum Failed).{Colors.RESET}"
            valid = False

        if not valid:
            print(f"\n{err}")
            print(f"\n{Colors.CYAN}[1] Try Again [2] Back to Menu{Colors.RESET}")
            c = input(f"\n{Colors.BOLD}Choice: {Colors.RESET}").strip()
            if c == '1': continue
            else: return

        res = get_keys(m)
        if res:
            print(f"\n{Colors.GREEN}[SUCCESS - VALIDATED]{Colors.RESET}")
            print(f"Address: {res['pub']}\nSecret:  {Colors.RED}{res['sec']}{Colors.RESET}")
            choice = input("\nSave as: [1] TXT [2] PNG [3] Both [N] None: ").strip().upper()
            if choice == '1': save_result(res, "key_analyser")
            elif choice == '2': save_as_png(res, "qrcode")
            elif choice == '3': save_result(res, "key_analyser"); save_as_png(res, "qrcode")
            if choice in ['1', '2', '3']: print(f"{Colors.GREEN}Saved to {RESULTS_DIR}!{Colors.RESET}")
            input("\nPress Enter to return to menu...")
            return

def tool_create_wallet():
    clear_screen(); print_banner()
    print(f"{Colors.YELLOW}--- GENERATE NEW PI WALLET 🆕 ---{Colors.RESET}")
    mnemo = Mnemonic(BIP39_LANGUAGE)
    phrase = mnemo.generate(strength=256)
    res = get_keys(phrase)
    if res:
        print(f"\n{Colors.GREEN}New Wallet Generated Successfully!{Colors.RESET}")
        print(f"{Colors.BOLD}Passphrase:{Colors.RESET} {Colors.CYAN}{res['mnemonic']}{Colors.RESET}")
        print(f"Address:    {res['pub']}")
        print(f"Secret:     {Colors.RED}{res['sec']}{Colors.RESET}")
        
        choice = input("\nSave Security Card as: [1] TXT [2] PNG [3] Both [N] None: ").strip().upper()
        if choice == '1': save_result(res, "new_wallet")
        elif choice == '2': save_as_png(res, "qrcode")
        elif choice == '3': save_result(res, "new_wallet"); save_as_png(res, "qrcode")
    input("\nPress Enter...")

def tool_recovery_variants():
    while True:
        clear_screen(); print_banner()
        print(f"{Colors.YELLOW}--- RECOVERY: UNCERTAIN/MISTYPED WORDS ---{Colors.RESET}")
        target = input(f"\n{Colors.BLUE}Target Public Address (G...): {Colors.RESET}").strip()
        if not target: return
        
        base_raw = input(f"{Colors.BLUE}Base 24-word Phrase: {Colors.RESET}").strip()
        if not base_raw: return
        base_words = clean_input_phrase(base_raw).split()
        if len(base_words) != 24:
            print(f"{Colors.RED}[ERROR] Base phrase must be 24 words.{Colors.RESET}"); input("\nPress..."); continue

        num = get_int_input("\nHow many word positions are uncertain? (1-3): ", 1, 3)
        if num == -1: return

        uncertain_data = []
        wordlist = Mnemonic(BIP39_LANGUAGE).wordlist
        for i in range(1, num+1):
            while True:
                pos = get_int_input(f"Uncertain position (1-24) for word {i}: ", 1, 24)
                if pos == -1: return
                idx = pos - 1
                print(f"Current: '{base_words[idx]}'. Possible words (space separated):")
                w_list = input("> ").strip().lower().split()
                if not w_list: continue
                uncertain_data.append((idx, w_list)); break
        
        print(f"\n{Colors.YELLOW}[*] Scanning combinations...{Colors.RESET}")
        param_list = []
        for i in range(24):
            match = next((u[1] for u in uncertain_data if u[0] == i), None)
            param_list.append(match if match else [base_words[i]])

        total = 1
        for p in param_list: total *= len(p)
        found = False
        try:
            for comb in tqdm(itertools.product(*param_list), total=total, desc="Scanning"):
                phrase = " ".join(comb)
                if Mnemonic(BIP39_LANGUAGE).check(phrase):
                    res = get_keys(phrase)
                    if res and res['pub'] == target:
                        save_result(res, "variant_found")
                        print(f"\n{Colors.GREEN}[MATCH FOUND]: {phrase}{Colors.RESET}")
                        found = True; break
        except KeyboardInterrupt: break
        
        if found: input("\nPress Enter..."); return
        else:
            print(f"\n{Colors.RED}[NOT FOUND]{Colors.RESET}")
            if input("Try again? (y/n): ").lower() != 'y': return

def tool_flexible_missing_recovery():
    while True:
        clear_screen(); print_banner()
        print(f"{Colors.YELLOW}--- RECOVERY: MISSING WORDS PRO ---{Colors.RESET}")
        target = input(f"\n{Colors.BLUE}Target Public Address (G...): {Colors.RESET}").strip()
        if not target: return
        
        num = get_int_input("\nHow many words are missing? (1-2): ", 1, 2)
        if num == -1: return

        partial = clean_input_phrase(input(f"{Colors.BLUE}Words you have: {Colors.RESET}")).split()
        if len(partial) != 24 - num:
            print(f"{Colors.RED}[ERROR] Invalid word count.{Colors.RESET}"); input("\nPress..."); continue

        print(f"\n{Colors.CYAN}[1] Known positions [2] Unknown positions{Colors.RESET}")
        mode = input("Choice: ").strip()
        
        pos_list = []
        if mode == '1':
            pos_list.append([get_int_input(f"Position {i+1} (1-24): ", 1, 24)-1 for i in range(num)])
        else:
            if num == 1: pos_list = [[i] for i in range(24)]
            else: pos_list = list(itertools.combinations(range(24), 2))

        wordlist = Mnemonic(BIP39_LANGUAGE).wordlist
        word_combs = list(itertools.product(wordlist, repeat=num))
        total = len(word_combs) * len(pos_list)
        
        print(f"\n{Colors.YELLOW}[*] Brute-forcing {total:,} possibilities...{Colors.RESET}")
        found = False
        try:
            with Pool(cpu_count()) as pool:
                for p_var in pos_list:
                    if found: break
                    args = ((partial, p_var, c, 24) for c in word_combs)
                    with tqdm(total=len(word_combs), desc=f"Pos {', '.join([str(x+1) for x in p_var])}") as pbar:
                        for res in pool.imap_unordered(missing_task, args, chunksize=1000):
                            pbar.update(1)
                            if res and res['pub'] == target:
                                save_result(res, "missing_match")
                                print(f"\n{Colors.GREEN}[MATCH FOUND]: {res['mnemonic']}{Colors.RESET}")
                                found = True; pool.terminate(); break
        except KeyboardInterrupt: break
        if found: input("\nPress Enter..."); return
        else:
            if input("\n[NOT FOUND] Try again? (y/n): ").lower() != 'y': return

def missing_task(args):
    base, pos, comb, length = args
    cur = base.copy()
    for p, w in sorted(zip(pos, comb)): cur.insert(p, w)
    phrase = " ".join(cur)
    if Mnemonic(BIP39_LANGUAGE).check(phrase): return get_keys(phrase)
    return None

def tool_recovery_swaps():
    while True:
        clear_screen(); print_banner()
        print(f"{Colors.YELLOW}--- RECOVERY: MULTI-WORD SWAPS (MIXED ORDER) ---{Colors.RESET}")
        target = input(f"\n{Colors.BLUE}Target Public Address (G...): {Colors.RESET}").strip()
        if not target: return
        
        words = clean_input_phrase(input(f"{Colors.BLUE}Paste Mixed Phrase: {Colors.RESET}")).split()
        if len(words) != 24:
            print(f"{Colors.RED}[ERROR] Must be 24 words.{Colors.RESET}"); input("\nPress..."); continue
            
        depth = get_int_input("\nSwap Depth (2-3 recommends): ", 2, 4)
        if depth == -1: return

        all_combs = list(itertools.combinations(itertools.combinations(range(24), 2), depth-1))
        print(f"\n{Colors.YELLOW}[*] Scanning {len(all_combs):,} swap patterns...{Colors.RESET}")
        found = False
        try:
            with Pool(cpu_count()) as pool:
                args = ((words, list(seq), [target]) for seq in all_combs)
                with tqdm(total=len(all_combs), desc="Swapping") as pbar:
                    for res in pool.imap_unordered(swap_task, args, chunksize=500):
                        pbar.update(1)
                        if res:
                            save_result(res, "swap_match")
                            print(f"\n{Colors.GREEN}[MATCH FOUND]: {res['mnemonic']}{Colors.RESET}")
                            found = True; pool.terminate(); break
        except KeyboardInterrupt: break
        if found: input("\nPress Enter..."); return
        else:
            if input("\n[NOT FOUND] Try again? (y/n): ").lower() != 'y': return

def swap_task(args):
    words, seq, targets = args
    cur = words.copy()
    for i, j in seq: cur[i], cur[j] = cur[j], cur[i]
    phrase = " ".join(cur)
    if Mnemonic(BIP39_LANGUAGE).check(phrase):
        res = get_keys(phrase)
        if res and (not targets or res['pub'] in targets): return res
    return None

def tool_typing_assistant():
    while True:
        clear_screen(); print_banner()
        print(f"{Colors.YELLOW}--- TYPO-PROOF TYPING ASSISTANT ---{Colors.RESET}")
        p = input(f"\n{Colors.BLUE}Type/Paste Passphrase: {Colors.RESET}").strip()
        if not p: return
        
        target = input(f"{Colors.BLUE}Target Public Address (optional): {Colors.RESET}").strip()
        if target and (not target.startswith('G') or len(target) != 56):
            print(f"{Colors.RED}[!] Invalid Pi Address format. Proceeding without target filtering.{Colors.RESET}")
            target = None

        words = p.lower().split(); wordlist = Mnemonic(BIP39_LANGUAGE).wordlist
        corrected, err_count = [], 0
        for w in words:
            if w in wordlist: corrected.append(w)
            else:
                err_count += 1
                sug = difflib.get_close_matches(w, wordlist, n=1, cutoff=0.5)
                print(f"  {Colors.RED}[ERR] '{w}'{Colors.RESET} -> Sug: {Colors.YELLOW}{sug[0] if sug else 'N/A'}{Colors.RESET}")
                corrected.append(sug[0] if sug else w)
        
        final = " ".join(corrected); is_v = Mnemonic(BIP39_LANGUAGE).check(final)
        score = max(0, 100 - (err_count * 10) - (0 if is_v else 30))
        
        print(f"\n{Colors.BOLD}Accuracy Score: {score}/100 | Checksum: {'✅ PASS' if is_v else '❌ FAIL'}{Colors.RESET}")
        
        if len(corrected) != 24:
            print(f"{Colors.RED}[!] WARNING: Corrected phrase has {len(corrected)} words (24 expected).{Colors.RESET}")

        if is_v:
            print(f"Corrected Phrase: {Colors.CYAN}{final}{Colors.RESET}")
            res = get_keys(final)
            if res:
                derived_addr = res['pub']
                print(f"Derived Address:  {Colors.WHITE}{derived_addr}{Colors.RESET}")
                
                if target:
                    if derived_addr == target:
                        print(f"\n{Colors.GREEN}████████████████████████████████████████████████████████████████████")
                        print(f"█ [MATCH FOUND!] This phrase matches your target address.        █")
                        print(f"████████████████████████████████████████████████████████████████████{Colors.RESET}")
                        save_result(res, "corrected_match")
                    else:
                        print(f"\n{Colors.RED}[!] MISMATCH: Derived address does not match your target.{Colors.RESET}")
                else:
                    if input("\nSave this result? (y/n): ").lower() == 'y':
                        save_result(res, "corrected_keys")
        else:
            print(f"\n{Colors.RED}[!] INVALID: This phrase does not pass the BIP39 checksum.{Colors.RESET}")
            if target and len(corrected) == 24:
                res = get_keys(final)
                if res:
                    print(f"Derived Address (Invalid Checksum): {res['pub']}")
        
        input("\nPress Enter to return to menu...")
        break

def tool_pattern_mask_searcher():
    while True:
        clear_screen(); print_banner()
        print(f"{Colors.YELLOW}--- PATTERN MASK SEARCHER 🔍 ---{Colors.RESET}")
        print(f"{Colors.WHITE}e.g., apple * d**r (asterisk for wildcards){Colors.RESET}")
        mask_raw = input(f"\n{Colors.BOLD}Phrase Mask: {Colors.RESET}").strip().lower()
        if not mask_raw: return
        masks = mask_raw.split(); wordlist = Mnemonic(BIP39_LANGUAGE).wordlist
        poss = []
        for m in masks:
            if m == "*": poss.append(wordlist)
            else:
                regex = "^" + m.replace("*", ".") + "$"
                matches = [w for w in wordlist if re.match(regex, w)]
                if not matches: print(f"{Colors.RED}[!] No match for {m}{Colors.RESET}"); input("\n..."); return
                poss.append(matches)
        total = 1
        for p in poss: total *= len(p)
        print(f"Combinations: {total:,}")
        if total > 500000 and input("Very large scan. Continue? (y/n): ").lower() != 'y': return
        valid = []
        for comb in tqdm(itertools.product(*poss), total=total, desc="Verifying"):
            ph = " ".join(comb)
            if Mnemonic(BIP39_LANGUAGE).check(ph): valid.append(ph)
        print(f"\nFound {len(valid)} Valid Phrases."); 
        if valid:
            for v in valid[:5]: print(f" - {v}")
            t = input("\nTarget Address to filter (optional): ").strip()
            if t:
                for v in valid:
                    r = get_keys(v)
                    if r and r['pub'] == t: print(f"{Colors.GREEN}[MATCH]: {v}{Colors.RESET}"); save_result(r, "pattern_match"); break
        input("\nPress Enter...")

def tool_storage_explorer():
    while True:
        clear_screen(); print_banner(); ensure_dirs()
        files = [f for f in os.listdir(RESULTS_DIR) if f.endswith('.txt')]
        for i, f in enumerate(files, 1): print(f" {i:<2}. {f}")
        c = input("\nIndex or 'B': ").strip()
        if c.upper() == "B" or not c: break
        try:
            with open(os.path.join(RESULTS_DIR, files[int(c)-1]), "r") as f:
                clear_screen(); print_banner(); print(f.read())
            input("\nEnter to go back...")
        except: pass

def tool_missing_space_finder():
    while True:
        clear_screen(); print_banner()
        print(f"{Colors.YELLOW}--- MISSING SPACE / JOINED WORDS FINDER 🔗 ---{Colors.RESET}")
        phrase_joined = input(f"\n{Colors.BLUE}Enter joined phrase or best guess: {Colors.RESET}").strip().lower()
        if not phrase_joined: return
        
        target = input(f"{Colors.BLUE}Target Public Address (optional): {Colors.RESET}").strip()
        if target and (not target.startswith('G') or len(target) != 56):
            print(f"{Colors.RED}[!] Address '{target}' is invalid format.{Colors.RESET}")
            target = None
        
        wordlist = Mnemonic(BIP39_LANGUAGE).wordlist
        words = clean_input_phrase(phrase_joined).split()
        repaired = []
        
        print(f"\n{Colors.YELLOW}[*] Attempting to rebuild words...{Colors.RESET}")
        for w in words:
            if w in wordlist: repaired.append(w)
            else:
                temp = w
                while temp:
                    found_sub = False
                    for i in range(len(temp), 2, -1):
                        sub = temp[:i]
                        if sub in wordlist:
                            repaired.append(sub)
                            temp = temp[i:]
                            found_sub = True
                            break
                    if not found_sub:
                        repaired.append(f"[{temp}]")
                        break
        
        final = " ".join(repaired)
        print(f"\nRepaired Phrase ({len(repaired)} words):")
        print(f"{Colors.CYAN}{final}{Colors.RESET}")
        
        if len(repaired) != 24:
            print(f"{Colors.RED}[!] WARNING: Phrase is NOT 24 words. BIP39 check will likely fail.{Colors.RESET}")

        is_v = Mnemonic(BIP39_LANGUAGE).check(final)
        print(f"Checksum Status: {'✅ PASS' if is_v else '❌ FAIL'}")
        
        if is_v:
            res = get_keys(final)
            if res:
                derived_addr = res['pub']
                print(f"Derived Address:  {Colors.WHITE}{derived_addr}{Colors.RESET}")
                
                if target:
                    if derived_addr == target:
                        print(f"\n{Colors.GREEN}████████████████████████████████████████████████████████████████████")
                        print(f"█ [MATCH FOUND!] Recovered phrase matches your target address.   █")
                        print(f"████████████████████████████████████████████████████████████████████{Colors.RESET}")
                        save_result(res, "space_repair_match")
                    else:
                        print(f"\n{Colors.RED}[!] MISMATCH: Derived address does not match your target.{Colors.RESET}")
                else:
                    if input("\nSave this repaired result? (y/n): ").lower() == 'y':
                        save_result(res, "space_repair")
        else:
            if target and len(repaired) == 24:
                # Still check if it matches even if checksum fails (though unlikely for valid wallets)
                res = get_keys(final)
                if res:
                    print(f"Derived Address (Invalid Checksum): {res['pub']}")
            print(f"\n{Colors.WHITE}TIP: Ensure you have exactly 24 valid BIP39 words.{Colors.RESET}")

        input("\nPress Enter to return to menu...")
        break

def main():
    if os.name == 'nt': os.system('color')
    ensure_dirs()
    while True:
        clear_screen(); print_banner()
        print(f"{Colors.YELLOW}--- PI NETWORK RECOVERY TOOLS (FREE VERSION) ---{Colors.RESET}")
        print("1. Recovery: Misspelled/Mistyped Words")
        print("2. Recovery: Multi-word Swaps (Mixed Order)")
        print("3. Recovery: Missing Words (Brute-force Pro)")
        print("4. Typo-Proof Typing Assistant (Correct)")
        print("5. Joined Word Finder (Missing Spaces) 🔗")
        print("6. Pattern Mask Word Searcher (s***m) 🔍")
        print("7. Pi Key Analyzer (Passphrase -> Address)")
        print("8. Result Storage Explorer 📁")
        print("9. Generate New Pi Wallet 🆕")
        print("Q. Exit")
        
        c = input(f"\n{Colors.BOLD}Select [1-9, Q]: {Colors.RESET}").strip().upper()
        if c == '1': tool_recovery_variants()
        elif c == '2': tool_recovery_swaps()
        elif c == '3': tool_flexible_missing_recovery()
        elif c == '4': tool_typing_assistant()
        elif c == '5': tool_missing_space_finder()
        elif c == '6': tool_pattern_mask_searcher()
        elif c == '7': tool_generate_keys()
        elif c == '8': tool_storage_explorer()
        elif c == '9': tool_create_wallet()
        elif c in ['Q', 'QUIT']: break

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: sys.exit(0)
